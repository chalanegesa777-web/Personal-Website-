<?php
// Copy to config.php (git-ignored) and fill in real values.
return [
  'db_host' => 'localhost',
  'db_name' => 'portfolio',
  'db_user' => 'your_user',
  'db_pass' => 'your_password',
  'notify_email' => 'you@example.com',
];

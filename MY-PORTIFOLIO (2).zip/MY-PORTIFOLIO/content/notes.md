# Content notes (fill in BEFORE editing the HTML)

- Headline:
- About text (120-150 words):
- Skills (only what you can explain in an interview):
  - Web:
  - Programming:
  - Networking:
  - Tools:
- Currently learning:
- Education (institution, program, dates):
- Experience: OBN internship - write results, not tasks
- Certificates (title, issuer, date, verify link):
- Contact: email, phone (optional), GitHub, city/country
- Per project: problem, solution, technologies, your role, screenshots, GitHub link

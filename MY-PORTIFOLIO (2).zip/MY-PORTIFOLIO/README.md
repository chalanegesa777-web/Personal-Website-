# Chala Negesa - Portfolio

Personal portfolio built with HTML, CSS and vanilla JavaScript. No build step.

## Run locally
Open the folder in VS Code and use the **Live Server** extension (needed because `projects.js` uses `fetch`).
Or run `python -m http.server 8000` in this folder and open http://localhost:8000.

## Structure
- `css/` base (tokens), layout, components, responsive
- `js/` nav, animations, projects, contact modules
- `data/projects.json` edit this to add or change projects
- `assets/` favicon (CV and certificate folders are kept for later)
- `backend/` optional PHP contact handler (not used by the current form)

## Before publishing
1. Replace every `YOUR-USERNAME`, `you@example.com`, `YOUR_FORM_ID` (index.html, projects.json, sitemap.xml, robots.txt).
2. Add `images/profile.webp` (about 640x800), `images/og-image.jpg` (1200x630) and project screenshots in `images/projects/` (`maintenance.webp`, `library.webp`, `quiz.webp`).
3. Replace the OBN "Industrial practice" label with your real dates.
4. Create a free form at formspree.io and paste its ID into the form `action`.

## Deploy (GitHub Pages)
Push to GitHub, then Settings > Pages > Deploy from branch > `main` / root.

/**
 * nav.js — Pill navbar: hamburger menu, active section pill, dark mode toggle
 */
export function initNav() {
  const hamburger = document.getElementById("hamburger");
  const navLinks  = document.getElementById("nav-links");
  const header    = document.getElementById("site-header");

  /* ── Hamburger toggle ─────────────────────────────────── */
  if (hamburger && navLinks) {
    const setOpen = (open) => {
      navLinks.classList.toggle("open", open);
      hamburger.setAttribute("aria-expanded", String(open));
      hamburger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      document.body.style.overflow = open ? "hidden" : "";
    };

    hamburger.addEventListener("click", () =>
      setOpen(!navLinks.classList.contains("open"))
    );

    // Close on link click
    navLinks.addEventListener("click", (e) => {
      if (e.target.closest(".nav-link")) setOpen(false);
    });

    // Close on Escape
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && navLinks.classList.contains("open")) {
        setOpen(false);
        hamburger.focus();
      }
    });

    // Close on outside click
    document.addEventListener("click", (e) => {
      if (
        navLinks.classList.contains("open") &&
        !navLinks.contains(e.target) &&
        !hamburger.contains(e.target)
      ) {
        setOpen(false);
      }
    });
  }

  /* ── Active section highlight (pill) ─────────────────── */
  const links = document.querySelectorAll(".nav-link");

  const setActive = (id) => {
    links.forEach((a) => {
      const active = a.dataset.section === id;
      a.classList.toggle("is-active", active);
      active
        ? a.setAttribute("aria-current", "true")
        : a.removeAttribute("aria-current");
    });
  };

  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) setActive(en.target.id);
      });
    },
    { rootMargin: "-40% 0px -55% 0px" }
  );

  document.querySelectorAll("section[id]").forEach((s) => io.observe(s));

  /* ── Dark mode toggle ─────────────────────────────────── */
  const btn     = document.getElementById("themeToggle");
  const moonSvg = btn?.querySelector(".icon-moon");
  const sunSvg  = btn?.querySelector(".icon-sun");

  // Load saved preference or default to light
  const saved = localStorage.getItem("theme") || "light";
  applyTheme(saved);

  btn?.addEventListener("click", () => {
    const current = document.documentElement.dataset.theme || "light";
    applyTheme(current === "dark" ? "light" : "dark");
  });

  function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("theme", theme);
    if (moonSvg) moonSvg.style.display = theme === "dark" ? "none" : "block";
    if (sunSvg)  sunSvg.style.display  = theme === "dark" ? "block" : "none";
  }

  /* ── Back to top button ───────────────────────────────── */
  const btt = document.getElementById("backToTop");
  if (btt) {
    window.addEventListener("scroll", () => {
      btt.classList.toggle("visible", window.scrollY > 400);
    }, { passive: true });
    btt.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }
}

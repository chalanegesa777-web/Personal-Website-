/**
 * animations.js
 * 1. Typing effect for the hero role line
 * 2. Scroll-triggered reveal (.reveal → .reveal.in)
 * 3. Skill bar fill animation
 */

/* ── 1. Typing effect ─────────────────────────────────────── */
const ROLES = [
  "Full-Stack Developer",
  "CS Student",
  "Web Developer",
  "Networking Enthusiast",
  "Cybersecurity Learner",
];

export function initTyping() {
  const el = document.getElementById("typed-text");
  if (!el) return;

  let roleIdx = 0;
  let charIdx = 0;
  let deleting = false;
  let paused   = false;

  // Respect reduced motion — just show first role statically
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    el.textContent = ROLES[0];
    return;
  }

  function tick() {
    const current = ROLES[roleIdx];

    if (paused) {
      paused = false;
      setTimeout(tick, deleting ? 60 : 1400);
      return;
    }

    if (!deleting) {
      // Typing forward
      el.textContent = current.slice(0, charIdx + 1);
      charIdx++;
      if (charIdx === current.length) {
        // Pause then start deleting
        deleting = true;
        paused   = true;
        setTimeout(tick, 1600);
        return;
      }
      setTimeout(tick, 90);
    } else {
      // Deleting
      el.textContent = current.slice(0, charIdx - 1);
      charIdx--;
      if (charIdx === 0) {
        deleting = false;
        roleIdx  = (roleIdx + 1) % ROLES.length;
        setTimeout(tick, 380);
        return;
      }
      setTimeout(tick, 50);
    }
  }

  // Small initial delay so the page loads first
  setTimeout(tick, 800);
}

/* ── 2. Scroll reveal ─────────────────────────────────────── */
export function initReveal() {
  // Immediately show elements already in viewport
  const allReveal = document.querySelectorAll(".reveal");

  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    allReveal.forEach((el) => el.classList.add("in"));
    return;
  }

  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) {
          en.target.classList.add("in");
          io.unobserve(en.target);
        }
      });
    },
    { threshold: 0.12 }
  );

  allReveal.forEach((el) => io.observe(el));
}

/* ── 3. Skill bars ────────────────────────────────────────── */
export function initSkillBars() {
  const fills = document.querySelectorAll(".skill-fill");
  if (!fills.length) return;

  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    fills.forEach((f) => {
      f.style.width = (f.dataset.width || 0) + "%";
    });
    return;
  }

  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) {
          const pct = en.target.dataset.width || 0;
          // Small delay so the section fade-in finishes first
          setTimeout(() => { en.target.style.width = pct + "%"; }, 200);
          io.unobserve(en.target);
        }
      });
    },
    { threshold: 0.3 }
  );

  fills.forEach((f) => io.observe(f));
}

/**
 * projects.js
 * Fetches data/projects.json and renders image-grid style project cards.
 * Hover reveals an overlay with title, description, tech tags and action links.
 */

/* ── Icon SVGs ───────────────────────────────────────────── */
const ICON = {
  github: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/></svg>`,
  demo:   `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`,
  code:   `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
  brain:  `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2z"/></svg>`,
  db:     `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>`,
  shield: `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
  book:   `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`,
  bank:   `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="3" y1="22" x2="21" y2="22"/><line x1="6" y1="18" x2="6" y2="11"/><line x1="10" y1="18" x2="10" y2="11"/><line x1="14" y1="18" x2="14" y2="11"/><line x1="18" y1="18" x2="18" y2="11"/><polygon points="12 2 20 7 4 7"/></svg>`,
  quiz:   `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`,
  person: `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`
};

/* ── Pick placeholder icon + colour theme by project title ── */
function getTheme(p) {
  const t = p.title.toLowerCase();
  const cat = p.category || "web";

  if (cat === "ml" || t.includes("prediction") || t.includes("machine"))
    return { icon: ICON.brain,  bg: "linear-gradient(135deg,#f5f3ff,#ede9fe)", color: "#7c3aed" };
  if (t.includes("library"))
    return { icon: ICON.book,   bg: "linear-gradient(135deg,#f0fdf4,#dcfce7)", color: "#16a34a" };
  if (t.includes("bank"))
    return { icon: ICON.bank,   bg: "linear-gradient(135deg,#fefce8,#fef9c3)", color: "#ca8a04" };
  if (t.includes("quiz"))
    return { icon: ICON.quiz,   bg: "linear-gradient(135deg,#fff7ed,#ffedd5)", color: "#ea580c" };
  if (t.includes("maintenance") || t.includes("equipment"))
    return { icon: ICON.shield, bg: "linear-gradient(135deg,#eff6ff,#dbeafe)", color: "#2563eb" };
  if (t.includes("portfolio"))
    return { icon: ICON.person, bg: "linear-gradient(135deg,#fdf4ff,#fae8ff)", color: "#a21caf" };
  return   { icon: ICON.code,   bg: "linear-gradient(135deg,#f0f4f8,#e2e8f0)", color: "#475569" };
}

/* ── Category label ─────────────────────────────────────── */
const CATEGORY_LABEL = { web: "Web App", ml: "Machine Learning", mobile: "Mobile", other: "Project" };
const CATEGORY_COLOR = {
  web: { bg: "rgba(37,99,235,.1)",    color: "#2563eb" },
  ml:  { bg: "rgba(124,58,237,.1)",   color: "#7c3aed" },
  mobile: { bg: "rgba(22,163,74,.1)", color: "#16a34a" },
  other: { bg: "rgba(71,85,105,.1)",  color: "#475569" }
};

/* ── Build one card ─────────────────────────────────────── */
function buildCard(p) {
  const theme = getTheme(p);
  const cat   = p.category || "web";
  const catStyle = CATEGORY_COLOR[cat] || CATEGORY_COLOR.other;

  const article = document.createElement("article");
  article.className = "proj-card reveal";

  /* Image / placeholder area */
  const imgWrap = document.createElement("div");
  imgWrap.className = "proj-img-wrap";

  /* Coloured placeholder shown until image loads */
  const placeholder = document.createElement("div");
  placeholder.className = "proj-placeholder";
  placeholder.setAttribute("aria-hidden", "true");
  placeholder.style.background = theme.bg;
  placeholder.style.color = theme.color;
  placeholder.innerHTML = theme.icon;
  imgWrap.append(placeholder);

  if (p.image) {
    const img = document.createElement("img");
    img.src      = p.image;
    img.alt      = `Screenshot of ${p.title}`;
    img.loading  = "lazy";
    img.decoding = "async";
    img.width    = 640;
    img.height   = 480;
    img.addEventListener("load",  () => img.style.opacity = "1");
    img.addEventListener("error", () => img.remove());
    img.style.opacity = "0";
    img.style.transition = "opacity .35s ease";
    imgWrap.append(img);
  }

  /* Category pill in top-left */
  const catPill = document.createElement("span");
  catPill.className = "proj-cat-pill";
  catPill.textContent = CATEGORY_LABEL[cat] || cat;
  catPill.style.background = catStyle.bg;
  catPill.style.color       = catStyle.color;
  imgWrap.append(catPill);

  /* Hover overlay */
  const overlay = document.createElement("div");
  overlay.className = "proj-overlay";
  overlay.setAttribute("aria-hidden", "true");

  const title = document.createElement("h3");
  title.textContent = p.title;

  const desc = document.createElement("p");
  desc.textContent = p.desc || "";

  /* Feature bullets (max 3 to keep overlay clean) */
  if (p.features && p.features.length) {
    const ul = document.createElement("ul");
    ul.className = "proj-overlay-features";
    p.features.slice(0, 3).forEach((f) => {
      const li = document.createElement("li");
      li.textContent = f;
      ul.append(li);
    });
    overlay.append(title, desc, ul);
  } else {
    overlay.append(title, desc);
  }

  /* Tech tags */
  const tagWrap = document.createElement("div");
  tagWrap.className = "proj-tags";
  (p.tags || []).forEach((t) => {
    const s = document.createElement("span");
    s.textContent = t;
    tagWrap.append(s);
  });
  overlay.append(tagWrap);

  /* Action links */
  const links = document.createElement("div");
  links.className = "proj-overlay-links";
  const mkLink = (href, label, icon) => {
    const a = document.createElement("a");
    a.href   = href;
    a.target = "_blank";
    a.rel    = "noopener noreferrer";
    a.setAttribute("aria-label", `${label} — ${p.title}`);
    a.innerHTML = icon + label;
    return a;
  };
  if (p.live)   links.append(mkLink(p.live,   "Live Demo", ICON.demo));
  if (p.github) links.append(mkLink(p.github, "GitHub",   ICON.github));
  overlay.append(links);

  imgWrap.append(overlay);
  article.append(imgWrap);
  return article;
}

/* ── Error fallback ──────────────────────────────────────── */
function renderError(grid) {
  grid.innerHTML = "";
  const p = document.createElement("p");
  p.className = "muted text-center";
  p.style.cssText = "grid-column:1/-1;padding:48px 0;";
  p.textContent = "Projects couldn't load. Run the site through a local server (XAMPP / Live Server).";
  grid.append(p);
}

/* ── Main entry point ────────────────────────────────────── */
export async function initProjects() {
  const grid = document.getElementById("project-grid");
  if (!grid) return;

  try {
    const res = await fetch("data/projects.json");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const projects = await res.json();

    grid.replaceChildren(...projects.map(buildCard));

    /* Scroll-triggered reveal with stagger */
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      grid.querySelectorAll(".reveal").forEach((c) => c.classList.add("in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en, i) => {
          if (en.isIntersecting) {
            setTimeout(() => en.target.classList.add("in"), i * 90);
            io.unobserve(en.target);
          }
        });
      },
      { threshold: 0.06 }
    );
    grid.querySelectorAll(".reveal").forEach((c) => io.observe(c));

  } catch (err) {
    console.error("initProjects:", err);
    renderError(grid);
  }
}

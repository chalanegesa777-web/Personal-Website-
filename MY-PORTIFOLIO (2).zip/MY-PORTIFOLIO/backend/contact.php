<?php
// Version 2 only: needs PHP + MySQL hosting.
// Table: CREATE TABLE messages (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), email VARCHAR(150), message TEXT, created_at DATETIME);
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit(json_encode(['error'=>'Method not allowed'])); }
if (!empty($_POST['_gotcha'])) { exit(json_encode(['ok'=>true])); }
if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(403); exit(json_encode(['error'=>'Invalid token'])); }

$name  = trim(strip_tags($_POST['name'] ?? ''));
$email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
$msg   = trim(strip_tags($_POST['message'] ?? ''));
if (!$name || !$email || strlen($msg) < 10) { http_response_code(422); exit(json_encode(['error'=>'Invalid input'])); }

$c = require __DIR__ . '/config.php';
$pdo = new PDO("mysql:host={$c['db_host']};dbname={$c['db_name']};charset=utf8mb4", $c['db_user'], $c['db_pass'],
  [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$pdo->prepare('INSERT INTO messages (name,email,message,created_at) VALUES (?,?,?,NOW())')->execute([$name,$email,$msg]);
@mail($c['notify_email'], 'Portfolio message from '.$name, $msg, "Reply-To: $email");
echo json_encode(['ok'=>true]);

/**
 * main.js — Entry point: initialises all modules
 */
import { initNav }                       from "./nav.js";
import { initTyping, initReveal, initSkillBars } from "./animations.js";
import { initProjects }                  from "./projects.js";
import { initContact }                   from "./contact.js";

// Inject spin keyframe for contact button loading state
const style = document.createElement("style");
style.textContent = `@keyframes spin { to { transform: rotate(360deg); } }`;
document.head.appendChild(style);

document.addEventListener("DOMContentLoaded", () => {
  initNav();          // Pill navbar, hamburger, dark mode, back-to-top
  initTyping();       // Typed text effect in hero
  initReveal();       // Scroll-triggered .reveal → .reveal.in
  initSkillBars();    // Animate skill progress bars on scroll
  initProjects();     // Load + render project cards from JSON
  initContact();      // Contact form validation + async submit

  // Keep copyright year current
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();
});

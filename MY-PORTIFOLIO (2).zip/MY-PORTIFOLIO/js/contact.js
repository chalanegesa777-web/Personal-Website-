/**
 * contact.js — Form validation and async Formspree submission
 */
export function initContact() {
  const form   = document.getElementById("contact-form");
  const status = document.getElementById("form-status");
  if (!form || !status) return;

  const btn = form.querySelector("button[type=submit]");

  const setStatus = (msg, type = "") => {
    status.textContent = msg;
    status.className   = type;
  };

  const validate = (field) => {
    const bad = !field.checkValidity() || !field.value.trim();
    field.classList.toggle("invalid", bad);
    field.setAttribute("aria-invalid", String(bad));
    return !bad;
  };

  // Validate on blur for instant feedback
  form.querySelectorAll("[required]").forEach((f) => {
    f.addEventListener("blur",  () => validate(f));
    f.addEventListener("input", () => { if (f.classList.contains("invalid")) validate(f); });
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus("");

    // Honeypot
    if (form.elements["_gotcha"]?.value) return;

    // Validate all required fields
    let allOk = true;
    form.querySelectorAll("[required]").forEach((f) => {
      if (!validate(f)) allOk = false;
    });
    if (!allOk) {
      setStatus("Please fill in all required fields correctly.", "error");
      form.querySelector(".invalid")?.focus();
      return;
    }

    // Disable button, show spinner
    btn.disabled = true;
    const origHTML = btn.innerHTML;
    btn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
        stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"
        style="animation:spin .7s linear infinite" aria-hidden="true">
        <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
      </svg>
      Sending…
    `;

    try {
      const res = await fetch(form.action, {
        method: "POST",
        body: new FormData(form),
        headers: { Accept: "application/json" },
      });
      if (!res.ok) throw new Error("Server error");

      form.reset();
      form.querySelectorAll("[required]").forEach((f) => {
        f.classList.remove("invalid");
        f.removeAttribute("aria-invalid");
      });
      setStatus("✓ Message sent! I'll get back to you soon.", "success");

    } catch {
      setStatus("Sending failed. Please email me directly at you@example.com.", "error");
    } finally {
      btn.disabled  = false;
      btn.innerHTML = origHTML;
    }
  });
}
